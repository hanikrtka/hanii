<!-- resources/views/matakuliah/create.blade.php -->


<?php $__env->startSection('content'); ?>
    <h1>Tambah Mata Kuliah</h1>
    <form action="<?php echo e(route('matakuliah.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="nama_mk">Nama Mata Kuliah</label>
            <input type="text" name="nama_mk" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary">Simpan</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ACER\perkuliahan\resources\views/matakuliah/create.blade.php ENDPATH**/ ?>