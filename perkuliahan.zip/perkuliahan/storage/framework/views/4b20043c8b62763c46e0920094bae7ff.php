<!-- resources/views/matakuliah/index.blade.php -->


<?php $__env->startSection('content'); ?>
    <h1>Data Mata Kuliah</h1>
    <a href="<?php echo e(route('matakuliah.create')); ?>" class="btn btn-primary">Tambah Mata Kuliah</a>

    <table class="table">
        <thead>
            <tr>
                <th>Nama MK</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $mataKuliahs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mataKuliah): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($mataKuliah->nama_mk); ?></td>
                    <td>
                        <a href="<?php echo e(route('matakuliah.show', $mataKuliah->id)); ?>" class="btn btn-info">Detail</a>
                        <a href="<?php echo e(route('matakuliah.edit', $mataKuliah->id)); ?>" class="btn btn-warning">Edit</a>
                        <form action="<?php echo e(route('matakuliah.destroy', $mataKuliah->id)); ?>" method="POST" style="display: inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">Hapus</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ACER\perkuliahan\resources\views/matakuliah/index.blade.php ENDPATH**/ ?>