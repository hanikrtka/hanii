<!-- resources/views/prodi/create.blade.php -->


<?php $__env->startSection('content'); ?>
    <h1>Tambah Program Studi</h1>
    <form action="<?php echo e(route('prodi.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="nama_prodi">Nama Program Studi</label>
            <input type="text" name="nama_prodi" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary">Simpan</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ACER\perkuliahan\resources\views/prodi/create.blade.php ENDPATH**/ ?>