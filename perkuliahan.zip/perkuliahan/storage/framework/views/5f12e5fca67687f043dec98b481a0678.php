<!-- resources/views/mahasiswa/show.blade.php -->


<?php $__env->startSection('content'); ?>
    <h1>Detail Mahasiswa</h1>
    <p>NIM: <?php echo e($mahasiswa->nim); ?></p>
    <p>Nama: <?php echo e($mahasiswa->nama); ?></p>
    <p>Program Studi: <?php echo e($mahasiswa->prodi->nama_prodi); ?></p>
    <a href="<?php echo e(route('mahasiswa.index')); ?>" class="btn btn-secondary">Kembali</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ACER\perkuliahan\resources\views/mahasiswa/show.blade.php ENDPATH**/ ?>