<!-- resources/views/dosen/index.blade.php -->


<?php $__env->startSection('content'); ?>
    <h1>Data Dosen</h1>
    <a href="<?php echo e(route('dosen.create')); ?>" class="btn btn-primary">Tambah Dosen</a>

    <table class="table">
        <thead>
            <tr>
                <th>NIP</th>
                <th>Nama</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $dosens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($dosen->nip); ?></td>
                    <td><?php echo e($dosen->nama); ?></td>
                    <td>
                        <a href="<?php echo e(route('dosen.show', $dosen->id)); ?>" class="btn btn-info">Detail</a>
                        <a href="<?php echo e(route('dosen.edit', $dosen->id)); ?>" class="btn btn-warning">Edit</a>
                        <form action="<?php echo e(route('dosen.destroy', $dosen->id)); ?>" method="POST" style="display: inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">Hapus</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ACER\perkuliahan\resources\views/dosen/index.blade.php ENDPATH**/ ?>